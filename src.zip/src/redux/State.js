
export let state = {
    profilePage: {
        posts: [
            {id: 1, message: 'Hi man! How are you?', likeCount: 5},
            {id: 2, message: 'My fist post!', likeCount: 9},
            {id: 3, message: 'Cool!!!', likeCount: 10},
            {id: 4, message: 'I\'m fine :-)', likeCount: 3},
            {id: 5, message: 'Where you been?', likeCount: 13},
            {id: 6, message: 'Learn JS!', likeCount: 19},
            ]
    },
    dialogsPage: {
        dialogs: [
            {id: 1, name: 'Dimych', image:'./components/Friends/imgFriends/1.png'},
            {id: 2, name: 'Roman', image:'./components/Friends/imgFriends/2.png'},
            {id: 3, name: 'Leha', image:'./components/Friends/imgFriends/3.png'},
            {id: 4, name: 'Ivan'},
            {id: 5, name: 'Sveta'},
        ],
        messages: [
            {id: 1, message: 'Hi'},
            {id: 2, message: 'How are you? How are you? How are you? How are you? How are you? How are you?How are you? How are you? How are you? How are you? How are you? How are you? How are you?How are you? How are you? How are you?  How are you? How are you? How are you?'},
            {id: 3, message: 'Yo!'},
            {id: 4, message: 'WTF?:-)'},
            {id: 5, message: ':-)'},
        ]
    },
    navBar: {

    }
};